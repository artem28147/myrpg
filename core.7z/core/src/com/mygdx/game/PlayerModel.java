package com.mygdx.game;

import java.util.LinkedList;
import java.util.List;

public class PlayerModel extends UnitModel{
    PlayerModel(){
        setPower(5);
    }

    private List<Item> items = new LinkedList<Item>();
    private List<Effect> effects = new LinkedList<Effect>();
    private int xp=0;

    public List<Item> getItems() {
        return items;
    }

    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }

    public void addItem(Item item){
        items.add(item);
    }

    public void addEffect(Effect effect){
        effects.add(effect);
    }

    public void removeEffect(Effect effect){
        effects.remove(effect);
    }
}
