package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.List;

public class PlayerController extends UnitController {
    private List<Item> shop = new LinkedList<Item>();
    SpriteBatch batch;
    boolean inventoryOpened = false;
    boolean shopOpened = false;
    Texture shopBackground = new Texture("shopBackground.jpg");
    Texture inventoryBackground = new Texture("inventoryBackground.jpg");
    BitmapFont font = new BitmapFont();
    PlayerController(SpriteBatch b) {
        batch = b;
        setModel(new PlayerModel());
        setView(new PlayerView());
        Gdx.input.setInputProcessor(new InputAdapter() {
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                outer().interact(screenX, screenY);
                return true;
            }
        });
    }

    @Override
    public PlayerView getView() {
        return (PlayerView) super.getView();
    }

    @Override
    public PlayerModel getModel() {
        return (PlayerModel) super.getModel();
    }

    public void attack(UnitController enemy, Position pos) {
        super.attack(enemy);
        getView().setAttack();
    }

    private void openInventory() {
        inventoryOpened = true;
    }

    public void interact(int x, int y) {
        //
        if (x > 895 && y > 15 && x < 945 && y < 65) {
            if (inventoryOpened == true)
                inventoryOpened = false;
            else {
                shopOpened = false;
                inventoryOpened = true;
            }
        }
        else if (x > 845 && y > 15 && x < 895 && y < 65) {
            if (shopOpened == true)
                shopOpened = false;
            else {
                inventoryOpened = false;
                shopOpened = true;
            }
        }
        else {
            for (UnitController mob : new ArrayList<UnitController>(getField().getUnits()))
                if (mob instanceof MonsterController)
                    //Проверяем, что курсор на монстрве
                    if (Math.abs(x - 35 - mob.getModel().getPosition().getX()) < mob.getModel().getSize().x && Math.abs(700 - y - mob.getModel().getPosition().getY()) < mob.getModel().getSize().y)
                        //Проверяем, что персонаж рядом с монстром
                        if (Math.abs(getModel().getPosition().getX() - mob.getModel().getPosition().getX()) < mob.getModel().getSize().x && Math.abs(getModel().getPosition().getY() - mob.getModel().getPosition().getY()) < mob.getModel().getSize().y) {
                            attack(mob, new Position(x, y));
                            return;
                        }
            for (Item item : new ArrayList<Item>(getField().getItems()))
                //Проверяем, что курсор на монстрве
                if (Math.abs(x - item.getPosition().getX()) < 100 && Math.abs(768 - y - item.getPosition().getY()) < 100)
                    //Проверяем, что персонаж рядом с монстром
                    if (Math.abs(getModel().getPosition().getX() - item.getPosition().getX()) < 100 && Math.abs(getModel().getPosition().getY() - item.getPosition().getY()) < 100) {
                        equipItem(item);
                        return;
                    }
            for (Effect effect : new ArrayList<Effect>(getField().getEffects()))
                //Проверяем, что курсор на монстрве
                if (Math.abs(x - effect.getPosition().getX()) < 100 && Math.abs(768 - y - effect.getPosition().getY()) < 100)
                    //Проверяем, что персонаж рядом с монстром
                    if (Math.abs(getModel().getPosition().getX() - effect.getPosition().getX()) < 100 && Math.abs(getModel().getPosition().getY() - effect.getPosition().getY()) < 100) {
                        useEffect(effect);
                        return;
                    }
        }
    }

    private void equipItem(Item item) {
        getField().removeItem(item);
        getModel().addItem(item);
        getModel().setHp(getModel().getHp() + item.getHp());
        getModel().setPower(getModel().getPower() + item.getPower());
        getModel().setAgility(getModel().getAgility() + item.getAgility());
    }

    private void useEffect(Effect effect) {
        getField().removeEffect(effect);
        getModel().addEffect(effect);
        getModel().setHp(getModel().getHp() + effect.getHp());
        getModel().setPower(getModel().getPower() + effect.getPower());
        getModel().setAgility(getModel().getAgility() + effect.getAgility());
    }

    public void finishEffect(Effect effect) {
        PlayerModel pm = (PlayerModel) getModel();
        pm.setHp(pm.getHp() - effect.getHp());
        pm.setPower(pm.getPower() - effect.getPower());
        pm.setAgility(pm.getAgility() - effect.getAgility());
        pm.removeEffect(effect);
    }

    public void dontRun() {
        if (!getView().isAttacking())
            getView().setStand();
    }

    private void removeEffect(Effect effect) {
        getModel().removeEffect(effect);
    }

    public PlayerController outer() {
        return PlayerController.this;
    }

    @Override
    public void draw(SpriteBatch batch) {
        getView().draw(batch, getModel().getPosition(), getModel().getCurrentHp(), getModel().getHp(), getModel().getLevel(), getModel().getXp(), getModel().getAgility(), getModel().getPower());
        if (inventoryOpened) {
            batch.draw(inventoryBackground,270, 170);
            int y = 570;
            for (Item item : new ArrayList<Item>(getModel().getItems())) {
                font.draw(batch, "power:" + String.valueOf(item.getPower()) + " hp:" + String.valueOf(item.getHp()) + " agility:" + String.valueOf(item.getAgility()), 460, y);
                y-=30;
            }
        }
        if (shopOpened) {
            batch.draw(shopBackground,270, 150);
            int y = 570;
            for (Item item : new ArrayList<Item>(getModel().getItems())) {
                font.draw(batch, "power:" + String.valueOf(item.getPower()) + " hp:" + String.valueOf(item.getHp()) + " agility:" + String.valueOf(item.getAgility()), 460, y);
                y-=30;
            }
        }
    }

    public void reactOnAttack(UnitController attacker) {
        if (super.getModel().getCurrentHp() <= 0)
            die();
    }

    @Override
    protected void die() {
        getModel().setCurrentHp(0);
    }

    public void increaseXp(int count) {
        getModel().setXp(getModel().getXp() + count);
        while (getModel().getXp() > 10) {
            getModel().setXp(getModel().getXp() - 10);
            getModel().setLevel(getModel().getLevel() + 1);
            getModel().setCurrentHp(getModel().getHp());
        }
        getView().setStand();
    }

}