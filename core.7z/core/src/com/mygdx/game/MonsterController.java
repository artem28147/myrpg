package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.util.ArrayList;
import com.mygdx.game.events.*;
public class MonsterController extends UnitController{
    private Field field = null;
    MonsterController(Position pos) {
        setModel(new MonsterModel());
        setView(new MonsterView());
        getModel().setPosition(pos);
    }
    MonsterController(Position pos, String name) {
        setModel(new MonsterModel());
        setView(new MonsterView());
        getModel().setPosition(pos);
        if (name=="bubble")
            turnToBubble();
    }
    public void reactOnAttack(UnitController attacker) {
        if (super.getModel().getCurrentHp()<=0)
            die(attacker);
        else
            attack(attacker);
    }

    protected void die(UnitController killer) {
        die();
        if (killer instanceof PlayerController) {
            PlayerController pc = (PlayerController)killer;
            MonsterModel mm = (MonsterModel)getModel();
            pc.increaseXp(mm.getXpReward());
        }
    }

    protected void die() {
        getField().removeUnit(this);
        fireMonsterDied();
    }

    @Override
    public void draw(SpriteBatch batch) {
        getView().draw(batch, getModel().getPosition());
    }

    public void turnToBubble(){
        getView().FRAME_COLS = new int[]{6,6,6,6,6,6};
        getView().setSprites("bubble.png");
        getView().constructFrames();
        getModel().setHp(500);
        getModel().setCurrentHp(500);
        getModel().setPower(1);
        MonsterModel mm = (MonsterModel)getModel();
        mm.setXpReward(7);
    }

    //Список слушателей действий монстра
    private ArrayList<MonsterActionListener> _listeners = new ArrayList();

    public void addMonsterActionListener(MonsterActionListener l) {
        _listeners.add(l);
    }

    public void removeMonsterActionListener(MonsterActionListener l){
        _listeners.remove(l);
    }

    protected void fireMonsterDied() {
        MonsterActionEvent event = new MonsterActionEvent(this);
        event.setMonster(this);
        for (MonsterActionListener listener : _listeners)
            listener.MonsterDied(event);
    }
}
