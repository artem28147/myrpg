package com.mygdx.game;

public class IntPair {
    IntPair(int xx,int yy){
        x=xx;
        y=yy;
    }
    public int x;
    public int y;
}
