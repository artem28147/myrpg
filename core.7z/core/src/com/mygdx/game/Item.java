package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Item {
    int power;
    int agility;
    int hp;
    private Position position = new Position(0,0);
    protected Texture sprite = new Texture("item.png");
    Item(int p, int a, int h, Position pos){
        power=p;
        agility=a;
        hp=h;
        position=pos;
    }
    public void draw(SpriteBatch batch) {
        batch.draw(sprite, position.getX(), position.getY());
    }

    public Position getPosition() {
        return position;
    }

    public int getPower() {
        return power;
    }

    public int getHp() {
        return hp;
    }

    public int getAgility() {
        return agility;
    }
}