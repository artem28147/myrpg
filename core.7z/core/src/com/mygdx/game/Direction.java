package com.mygdx.game;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
