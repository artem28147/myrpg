package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class MonsterView extends UnitView{
    MonsterView() {
        frameDuration=0.2f;
        FRAME_COLS = 8;
        walkSheet = new Texture(Gdx.files.internal("storm.png")); // #9
        reconstructFrames();
    }
}
