package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Effect {
    int power;
    int agility;
    int hp;
    int time;
    PlayerController player;
    Effect e = this;
    protected Texture sprite = new Texture("effect.png");
    private Position position = new Position(0,0);
    Effect(int p, int a, int h, int t, Position pos){
        power=p;
        agility=a;
        hp=h;
        time=t;
        position=pos;
    }
    public void draw(SpriteBatch batch) {
        batch.draw(sprite, position.getX(), position.getY());
    }
    public Position getPosition() {
        return position;
    }
    public int getPower() {
        return power;
    }

    public int getHp() {
        return hp;
    }

    public int getAgility() {
        return agility;
    }

    public void setPlayer(PlayerController p) {
        this.player = p;
        Ticking tickThread = new Ticking();
        tickThread.start();
    }

    public class Ticking extends Thread {
        public void run() {
            try {
                Thread.sleep(time*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            player.finishEffect(e);
            return;
        }
    }
}
