package com.mygdx.game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import java.util.Random;

abstract public class UnitView {
    enum Pose{LEFT,RIGHT,UP,DOWN,STAND,ATTACK};
    Pose currentPose = Pose.STAND;
    String standPath = "stand.png";
    String upPath = "vverh.png";
    String downPath = "vniz.png";
    String rightPath = "vpravo.png";
    String leftPath = "vlevo.png";
    String attackPath = "attack.png";
    float frameDuration = 0.08f;
    protected int FRAME_COLS = 1;
    protected int FRAME_ROWS = 1;
    protected Animation walkAnimation;
    protected Texture walkSheet;
    protected TextureRegion[] walkFrames;
    protected SpriteBatch spriteBatch;
    protected TextureRegion currentFrame;
    protected float stateTime;
    protected Texture sprite = new Texture(standPath);
    protected BitmapFont font = new BitmapFont();
    protected UnitView(){
        font.setColor(255.0f, 255.0f, 255.0f, 255.0f);
    }
    public String getSpritePath() {
        return standPath;
    }
    public void setSpritePath(String path) {
        this.standPath = path;
        sprite = new Texture(standPath);
    }
    public void draw(SpriteBatch batch, Position pos) {
        stateTime += Gdx.graphics.getDeltaTime();
        currentFrame = (TextureRegion)walkAnimation.getKeyFrame(stateTime, true);
        batch.draw(currentFrame, pos.getX(), pos.getY());
    }

    public void setSprite(Texture sprite) {
        this.sprite = sprite;
    }

    public void setLeft(){
        if (currentPose!=Pose.LEFT) {
            currentPose=Pose.LEFT;
            walkSheet = new Texture(Gdx.files.internal(leftPath));
            FRAME_COLS = 7;
            reconstructFrames();
        }
    }
    public void setRight(){
        if (currentPose!=Pose.RIGHT) {
            currentPose=Pose.RIGHT;
            walkSheet = new Texture(Gdx.files.internal(rightPath));
            FRAME_COLS = 7;
            reconstructFrames();
        }
    }
    public void setUp(){
        if (currentPose!=Pose.UP) {
            currentPose=Pose.UP;
            walkSheet = new Texture(Gdx.files.internal(upPath));
            FRAME_COLS = 8;
            reconstructFrames();
        }
    }
    public void setDown(){
        if (currentPose!=Pose.DOWN) {
            currentPose=Pose.DOWN;
            walkSheet = new Texture(Gdx.files.internal(downPath));
            FRAME_COLS = 7;
            reconstructFrames();
        }
    }

    public void setStand(){
        currentPose=Pose.STAND;
        walkSheet = new Texture(Gdx.files.internal(standPath));
        FRAME_COLS = 1;
        reconstructFrames();
    }

    public void setAttack(){
        if (currentPose!=Pose.ATTACK) {
            currentPose=Pose.ATTACK;
            walkSheet = new Texture(Gdx.files.internal(attackPath));
            FRAME_COLS = 5;
            reconstructFrames();
            AttackTime th = new AttackTime();
            th.start();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Gdx.app.postRunnable(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            setStand();
                            return;
                        }
                    });
                }
            }).start();
        }
    }
    public class AttackTime extends Thread {
        public void run() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            setStand();
            return;
        }
    }
    protected void reconstructFrames(){
        Random rand = new Random();
        TextureRegion[][] tmp = TextureRegion.split(walkSheet, walkSheet.getWidth()/FRAME_COLS, walkSheet.getHeight()/FRAME_ROWS); // #10
        walkFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
        int index=0;
        for (int i = 0; i < FRAME_ROWS; i++) {
            for (int j = 0; j < FRAME_COLS; j++) {
                walkFrames[index++] = tmp[i][j];
            }
        }
        walkAnimation = new Animation(frameDuration, walkFrames); // #11
        stateTime = 0 + rand.nextFloat() * (1f - 0);; // #13
    }
}
