package com.mygdx.game;

public class MonsterModel extends UnitModel{
    int xpReward=2;

    MonsterModel(){
        setSize(new IntPair(50,60));
    }
    public int getXpReward() {
        return xpReward;
    }

    public void setXpReward(int xpReward) {
        this.xpReward = xpReward;
    }
    
}
