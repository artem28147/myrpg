package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Input.Keys;
import com.mygdx.game.events.*;

import java.util.Random;


public class MyMmorpg extends ApplicationAdapter {
    SpriteBatch batch; //
    Texture img;
    Field field;
    PlayerController player;
    @Override
    public void create() {
        batch = new SpriteBatch();
        field = new Field();
        player = new PlayerController(batch);
        player.setField(field);
        //добавление игрока
        field.addUnit(player);
        //генерация монстров
        MonsterController mob;
        while (field.getUnits().size()<15) {
            //с 65% шансом создается сильный монстр, 35% - слабый
            if (new Random().nextFloat()<0.65f)
                mob = new MonsterController(new Position((Math.random() * (field.getWidth()-65)), Math.random() * (field.getLength()-85)));
            else
                mob = new MonsterController(new Position((Math.random() * (field.getWidth()-65)), Math.random() * (field.getLength()-85)),"bubble");
            field.addUnit(mob);
            mob.addMonsterActionListener(new MyMmorpg.Up());
            mob.setField(field);
        }
    }

    @Override
    public void render() {
        //обработка нажатий на кнопки ходьбы
        if(Gdx.input.isKeyPressed(Keys.A)) player.move(Direction.LEFT);
        else if(Gdx.input.isKeyPressed(Keys.D)) player.move(Direction.RIGHT);
        else if(Gdx.input.isKeyPressed(Keys.W)) player.move(Direction.UP);
        else if(Gdx.input.isKeyPressed(Keys.S)) player.move(Direction.DOWN);
        else player.stand();
        //Отрисовка фона и монстров
        batch.begin();
        batch.draw(field.getTexture(), 0, 0);
        for (UnitController unit : field.getUnits())
            unit.draw(batch);
        for (Effect effect : field.getEffects())
            effect.draw(batch);
        for (Item item : field.getItems())
            item.draw(batch);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
    }

    public class Up implements MonsterActionListener{
        @Override
        public void MonsterDied(MonsterActionEvent e) {
            Random rnd = new Random();
            int hp = rnd.nextInt(10) + 1;
            int pow = rnd.nextInt(10) + 1;
            int agi = rnd.nextInt(10) + 1;
            int time = rnd.nextInt(60) + 30;
            if (rnd.nextBoolean())
                field.addEffect(new Effect(pow,agi,hp,time,e.getMonster().getModel().getPosition()));
            else
                field.addItem(new Item(pow,agi,hp,e.getMonster().getModel().getPosition()));
        }
    }
}
