package com.mygdx.game;

abstract public class UnitModel {
    UnitController controller = null;
    private int hp = 5;
    private int currentHp = 5;
    private int power = 1;
    private int agility = 1;
    private Position position = new Position(0,0);
    private IntPair size = new IntPair(50,50);
    private int range;
    private int level=1;

    public int getAgility() {
        return agility;
    }

    public int getCurrentHp() {
        return currentHp;
    }

    public int getHp() {
        return hp;
    }

    public int getPower() {
        return power;
    }

    public int getRange() {
        return range;
    }

    public IntPair getSize() {
        return size;
    }

    public Position getPosition() {
        return position;
    }

    public int getLevel() {
        return level;
    }

    public void setController(UnitController c){
        controller=c;
    }
    public void setAgility(int agility) {
        this.agility = agility;
    }

    public void setCurrentHp(int currentHp) {
        this.currentHp = currentHp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public void setRange(int range) {
        this.range = range;
    }

    public void setSize(IntPair size) {
        this.size = size;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
