package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class PlayerView extends UnitView{
    PlayerView() {
        walkSheet = new Texture(Gdx.files.internal("stand.png")); // #9
        TextureRegion[][] tmp = TextureRegion.split(walkSheet, walkSheet.getWidth()/FRAME_COLS, walkSheet.getHeight()/FRAME_ROWS); // #10
        walkFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
        int index = 0;
        for (int i = 0; i < FRAME_ROWS; i++) {
            for (int j = 0; j < FRAME_COLS; j++) {
                walkFrames[index++] = tmp[i][j];
            }
        }
        walkAnimation = new Animation(0.100f, walkFrames); // #11
        spriteBatch = new SpriteBatch(); // #12
        stateTime = 0f; // #13
    }

    public void draw(SpriteBatch batch, Position pos, int currentHp, int hp, int level, int xp, int agility, int power) {
        stateTime += Gdx.graphics.getDeltaTime();
        currentFrame = (TextureRegion)walkAnimation.getKeyFrame(stateTime, true);
        //иконка
        batch.draw(currentFrame, pos.getX(), pos.getY());
        //уровень
        font.draw(batch, "Level: "+String.valueOf(level) , 950, 750);
        //опыт
        font.draw(batch, "XP:"+String.valueOf(xp)+"/10" , 950, 725);
        //хп
        font.draw(batch, "HP:"+String.valueOf(currentHp)+"/"+String.valueOf(hp) , 950, 700);
        //ловкость
        font.draw(batch, "Agility:"+String.valueOf(agility) , 950, 675);
        //сила
        font.draw(batch, "Power:"+String.valueOf(power) , 950, 650);
    }
}
