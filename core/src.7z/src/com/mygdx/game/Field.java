package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.mygdx.game.Position;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class Field {
    private int length=768;
    private int width=1024;
    private Texture texture = new Texture("map.jpg");
    List<UnitController> units = new ArrayList<UnitController>();
    List<Item> items = new ArrayList<Item>();
    List<Effect> effects = new ArrayList<Effect>();

    public Texture getTexture(){
        return texture;
    }
    public int getLength() {
        return length;
    }

    public int getWidth() {
        return width;
    }

    public List<UnitController> getUnits() {
        return units;
    }

    public List<Effect> getEffects() {
        return effects;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void isEmpty(Position pos) {
    }

    public void checkNeighbourPosition(Position pos) {
    }

    public Position generateNewPosition() {
        return new Position(0,0);
    }

    public void addUnit(UnitController u){
        units.add(u);
    }

    public void addEffect(Effect e){effects.add(e);}

    public void addItem(Item i){items.add(i);}

    public void removeUnit(UnitController u){units.remove(u);}

    public void removeEffect(Effect e){effects.remove(e);}

    public void removeItem(Item i){items.remove(i);}
}
